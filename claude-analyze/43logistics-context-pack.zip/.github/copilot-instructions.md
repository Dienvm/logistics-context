# Copilot instructions

Follow `AGENTS.md` at the repository root — it is the single source of project rules (stack, golden rules, conventions, definition of done).

Before generating code for a feature, open the matching file from `docs/context/` listed in the context map in `AGENTS.md` section 4. Never invent prices, transit times, addresses or phone numbers: they come from the database (`routes`, `route_rates`, `site_settings`) or `docs/context/01-business.md`.
