# CLAUDE.md

@AGENTS.md

Claude Code: the full project instructions are in `AGENTS.md` (imported above). Load files from `docs/context/` only when the task needs them — see the context map in section 4 of `AGENTS.md`.
