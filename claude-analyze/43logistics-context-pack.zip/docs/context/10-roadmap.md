# 10 — Roadmap & task specs

> Work one task at a time. Each task lists the context to load, the deliverable and acceptance criteria. Mark tasks done here (`[x]`) in the same PR.
> Prompt template for an agent: *"Implement task {ID} from docs/context/10-roadmap.md. Load AGENTS.md and the listed context files first. Stop and list questions if a fact is missing from 01-business.md."*

## Phase 0 — Foundation

- [ ] **F-01 Scaffold** — Next.js 16 (TypeScript, App Router, Turbopack, `src/`), pnpm, ESLint flat config, Prettier, Vitest, Playwright, `env.ts` (Zod). *Context:* 06. *Accept:* `pnpm dev/build/lint/typecheck/test` work; `cacheComponents: true`, `trailingSlash: true` in `next.config.ts`; Node ≥ 20.9.
- [ ] **F-02 Tokens & theme** — `scripts/build-tokens.ts` turns `data/design-tokens.json` (`proposed`) into `src/styles/theme.css` (`@theme`), Tailwind v4 wired, fonts via `next/font` (Be Vietnam Pro, Barlow Condensed, `latin`+`vietnamese`). *Context:* 04. *Accept:* `pnpm tokens` regenerates identical output; a `/dev/tokens` page (dev-only) shows colours/type scale; reduced-motion CSS present.
- [ ] **F-03 i18n** — next-intl routing (VI root, `/en`), `[locale]` layout, `messages/{vi,en}.json`, key-parity check script. *Context:* 08. *Accept:* `/` renders `lang="vi"`, `/en/` renders `lang="en"`; no auto redirect; parity check in CI.
- [ ] **F-04 Database** — Supabase project (Singapore region), Drizzle client + schema from 07, migrations, seed script with `data/seed/*`. *Context:* 07. *Accept:* `pnpm db:migrate && pnpm db:seed` on a fresh DB creates all tables with RLS enabled and 10 routes (8 active); `src/db` cannot be imported from client code (`server-only`).
- [ ] **F-05 Auth** — Clerk for `/admin` only, roles in `publicMetadata`, session claim `role`, `requireRole()`, Clerk webhook → `profiles`. *Context:* 06. *Accept:* unauthenticated `/admin` → sign-in; `editor` cannot open leads; public pages ship no Clerk JS (check bundle).
- [ ] **F-06 proxy.ts** — 410 rules, legacy `?page_id`/`?p` redirects, attribution cookie, next-intl, Clerk protection. *Context:* 05, 06. *Accept:* unit tests for matchers; `/tieu-de/` → 410; `/?page_id=705` → 301 `/gui-hang-di-singapore/`; `?utm_source=x` sets `43l_attr`.
- [ ] **F-07 Redirects** — CSV loader → `next.config.ts` `redirects()`/`rewrites()`; `scripts/check-redirects.ts`. *Context:* 05, `data/redirect-map.csv`. *Accept:* all 63 rows pass against `next start`.
- [ ] **F-08 CI** — GitHub Actions: lint, typecheck, unit, build, e2e (Playwright), check:redirects, Lighthouse CI (budgets from AGENTS.md).

## Phase 1 — Public site core

- [ ] **S-01 Layout** — Header (mega menu from `routes` + `route_rates` min price), MobileActionBar, Footer from `site_settings`, Breadcrumbs, `/go/[channel]` links. *Context:* 03, 04. *Accept:* 360/768/1280 screenshots; keyboard nav of mega menu; no CLS from sticky bar.
- [ ] **S-02 Contact tracker** — `app/go/[channel]/route.ts`: insert `contact_events`, 302 to channel URL (WhatsApp with `84` prefix), `event_id` shared with dataLayer push. *Context:* 05. *Accept:* e2e asserts row + 302 for each channel; invalid channel → 404.
- [ ] **S-03 Price engine** — pure functions: chargeable weight (max(actual, L×W×H/divisor)), rounding (`weight_rounding_kg`), band lookup, flat vs per-kg, open-ended bands, `contact_for_price`. *Context:* 01, 07. *Accept:* ≥ 20 unit tests incl. US 1.3 kg → 1.5 kg, SG 5 kg vs 6 kg band edge, volumetric > actual.
- [ ] **S-04 Route page template** — sections per 03 (hero, mini calculator, RateTable, pricing rules, process, goods, methods, compensation, FAQ, testimonials, related), metadata, JSON-LD (`Service`/`Offer`, `BreadcrumbList`, `FAQPage`), OG image. *Accept:* 7 outbound + SG→VN render from DB; unverified routes show "liên hệ" instead of prices; Lighthouse mobile ≥ 90/100/95.
- [ ] **S-05 Home** — per 03. *Accept:* H1 present; route bento from DB; no carousel above the fold; LCP image ≤ 150 KB.
- [ ] **S-06 Hubs** — `/dich-vu/`, `/nhap-hang/` comparison tables. 
- [ ] **S-07 Calculator page** — `/tinh-cuoc/` with Zustand store, "Gửi kết quả qua Zalo" (prefilled text), `calculate_quote` event. *Accept:* works without JS-fetching (rates embedded at build); accessible form errors.
- [ ] **S-08 Lead form** — Server Action, Zod, Turnstile, rate limit, consent, `after()` notifications/conversions, success/error states in VI/EN. *Accept:* e2e happy + validation paths; row has attribution fields; no email required.
- [ ] **S-09 About, Contact, Policies, 404** — templates; policy pages render markdown with TOC and "Cập nhật" date. *Accept:* footer has no `#` links.
- [ ] **S-10 SEO infra** — `buildMetadata`, `JsonLd`, `sitemap.ts`, `robots.ts`, RSS. *Accept:* sitemap lists only published+indexable URLs with alternates; CI SEO check (1 H1, canonical, hreflang reciprocal, JSON-LD parses).
- [ ] **S-11 Blog** — list (filter by route), article (TOC, CTA box, related route), `BlogPosting`. 
- [ ] **S-12 Prohibited goods** — `/hang-cam-gui/` grouped + filter; only rules with `approved_at`.
- [ ] **S-13 Consent & GTM** — Consent Mode v2 defaults, banner, GTM via `@next/third-parties`. *Accept:* no ad cookies before consent; events visible in GTM preview after consent.

## Phase 2 — Admin (staff CMS)

- [ ] **A-01 Admin shell** — `/admin` layout with Clerk `<UserButton>`, nav by role, React Query provider. 
- [ ] **A-02 Routes & rates editor** — CRUD bands, validity dates, `is_verified` toggle (admin only), preview of public table; actions call `updateTag('route:{key}')` + `revalidateTag('menu','max')`. *Accept:* editing a price shows on the public route page, mega menu and calculator after save (e2e).
- [ ] **A-03 Pages & translations** — block editor (form-based per block type), SEO fields with length counters, slug change → auto redirect row, status workflow (draft → review → published), "Create EN draft".
- [ ] **A-04 Media library** — upload (sharp conversion), required alt VI/EN, usage list.
- [ ] **A-05 FAQs, goods rules, testimonials** — with approval (`approved_at`) and consent (`consent_at`) gates.
- [ ] **A-06 Leads inbox** (sales) — DataTable (TanStack Query + Table), filters (status, route, source, date), status updates, notes, CSV export, attribution detail. *Accept:* `editor` gets 403.
- [ ] **A-07 Contact analytics** — counts of `contact_events` + leads by channel/route/source per week.
- [ ] **A-08 Redirects manager** — list/add/edit, hits counter.
- [ ] **A-09 Settings** — company, contacts, offices, hours, offers (Zod-validated forms).

## Phase 3 — Content & EN

- [ ] **C-01 Confirm facts** — close the blocking items in `11-open-questions.md` (prices, hours, addresses, legal info, active inbound routes).
- [ ] **C-02 Route copy** — rewrite 7 outbound + SG→VN from `legacy-copy/*` (unique per route, no competitor links), add FAQs (5–8 each), goods rules approved by ops.
- [ ] **C-03 Core pages copy** — home, about (real story/photos), contact, hubs, 5 policies (privacy covers Decree 13/2023).
- [ ] **C-04 Media** — migrate 175 used files per 09, new photos of warehouse/packing/team.
- [ ] **C-05 Blog** — migrate 2 posts (+ merge the 2023 post), plan 2 posts/month by route.
- [ ] **C-06 English** — EN for P0 pages per 08 workflow; human review of SEO fields.

## Phase 4 — Ads & conversions

- [ ] **T-01 Server-side conversions** — Meta CAPI, TikTok Events API (lead + contact clicks, `event_id` dedupe, consent-gated).
- [ ] **T-02 Google Ads** — conversions via GTM, Enhanced Conversions for leads; offline import of `won` leads by `gclid` (later).
- [ ] **T-03 Landing pages** — `/lp/[campaign]/` template + 1 LP per top route; checklist in 05.

## Phase 5 — Launch

- [ ] **L-01 Staging QA** — everything in `09-migration.md` step 7.
- [ ] **L-02 Go-live** — DNS, Search Console sitemap, monitoring (Sentry or similar, uptime), 4-week watch.

## Phase 6 — Later

- [ ] Inbound MY→VN, TH→VN pages (if confirmed) · tracking page (if a carrier API exists) · new routes (EU, AU, CA) · Zalo OA integration for lead notifications · reviews collection with consent.
