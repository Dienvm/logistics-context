# 06 — Architecture

## High-level

```
Browser ──► proxy.ts (Node runtime)
              ├─ 410 for dead WordPress paths, ?page_id / ?p= legacy IDs
              ├─ attribution cookie (utm_*, click IDs) on first landing
              ├─ next-intl locale routing (VI root, /en/*)
              └─ clerkMiddleware → protects /admin/* and /api/admin/*
           ──► App Router (React 19.2 Server Components, Cache Components)
              ├─ src/server/queries/*   ("use cache" + cacheTag) ──► Drizzle ──► Supabase Postgres
              ├─ src/server/actions/*   (Server Actions, Zod, requireRole) ──► Drizzle / Storage
              └─ app/go/[channel]/route.ts, app/api/* (route handlers)
           ──► Client islands: calculator, lead form, mobile bar, consent, admin screens
              ├─ Zustand (UI state)
              └─ TanStack Query (admin data grids / async client reads via route handlers or actions)
Supabase Storage (media, og, private) ◄── server uploads (service role) · public CDN reads
Clerk ◄── staff sign-in (admin/editor/sales)
GTM + server-side conversions (Meta CAPI, TikTok Events API, Google Ads)
```

Hosting assumption: Vercel (or any Node host supporting Next 16). Supabase region close to Vietnam (Singapore, `ap-southeast-1`). `NEEDS CONFIRMATION` of hosting choice.

## Folder structure

```
.
├── AGENTS.md · CLAUDE.md · .github/copilot-instructions.md
├── docs/context/*            # project knowledge (this pack)
├── docs/adr/*                # architecture decision records
├── data/                     # redirect-map.csv, design-tokens.json, media-inventory.csv, seed/*
├── drizzle/                  # generated SQL migrations
├── messages/{vi,en}.json     # UI strings (next-intl)
├── scripts/                  # seed.ts, import-wordpress.ts, build-tokens.ts, check-redirects.ts
├── src/
│   ├── app/
│   │   ├── [locale]/
│   │   │   ├── (site)/                       # public site layout (header, footer, mobile bar)
│   │   │   │   ├── page.tsx                  # home
│   │   │   │   ├── [slug]/page.tsx           # resolves page by (locale, slug): route, hub, about, contact, policy…
│   │   │   │   ├── kinh-nghiem/…  /  guides/…# blog (localized pathnames via next-intl)
│   │   │   │   └── lp/[campaign]/page.tsx    # ads landing (own minimal layout)
│   │   │   └── layout.tsx                    # <html lang>, fonts, NextIntlClientProvider
│   │   ├── admin/                            # Clerk-protected CMS (not localized)
│   │   ├── go/[channel]/route.ts             # contact click tracker
│   │   ├── api/…                             # webhooks (Clerk), revalidate, admin JSON for React Query
│   │   ├── sitemap.ts · robots.ts
│   │   └── global-error.tsx · not-found.tsx
│   ├── components/{ui,blocks,layout,admin}/
│   ├── db/                     # drizzle client + schema/*
│   ├── server/{queries,actions,services}/   # services: conversions, storage, email
│   ├── lib/{seo,i18n,format,tracking,validation}/
│   ├── stores/                 # zustand stores
│   ├── styles/{theme.css,globals.css}
│   └── proxy.ts                # (root-level `proxy.ts` if not using src/)
└── tests/{unit,e2e}/
```

Dynamic `[slug]` resolution: one catch route looks up `page_translations` by `(locale, slug)` and renders the template for `pages.type` (`route_outbound`, `route_inbound`, `hub`, `about`, `contact`, `policy`, `generic`). `generateStaticParams` returns all published slugs per locale.

## Rendering & caching (Next 16 Cache Components)

`next.config.ts`:

```ts
const nextConfig: NextConfig = {
  cacheComponents: true,
  trailingSlash: true,
  reactCompiler: true,            // optional; measure build time
  images: { remotePatterns: [{ protocol: 'https', hostname: '<project>.supabase.co', pathname: '/storage/v1/object/public/**' }], formats: ['image/avif', 'image/webp'] },
  async redirects() { return loadRedirectsFromCsv('data/redirect-map.csv') },
  async rewrites() { return [{ source: '/wp-content/uploads/:path*', destination: 'https://<project>.supabase.co/storage/v1/object/public/media/uploads/:path*' }] },
}
```

| Data | Pattern |
| --- | --- |
| Page content, routes, rates, FAQs, menus, settings | Query functions marked `"use cache"`, `cacheLife('max')`, `cacheTag('page:{id}')`, `cacheTag('route:{key}')`, `cacheTag('settings')`, `cacheTag('menu')` |
| Admin edit (Server Action) | Write via Drizzle → `updateTag(tag)` (read-your-writes in the admin) and `revalidateTag(tag, 'max')` where SWR is fine |
| Lead form / contact events | Not cached; Server Action / route handler |
| Request-specific bits (attribution cookie, consent) | Read inside a `<Suspense>` boundary or on the client; never inside a cached function |

Note: in Next 16 `revalidateTag` takes a second `cacheLife` argument; `updateTag` and `refresh` exist only in Server Actions. `params`, `searchParams`, `cookies()`, `headers()` are async.

i18n with Cache Components: pass `locale` explicitly into cached query functions (it becomes part of the cache key); call next-intl's `setRequestLocale(locale)` in layouts/pages for static rendering. `NEEDS CONFIRMATION`: verify the installed next-intl version's guidance for `cacheComponents` before scaffolding (record in an ADR).

## `proxy.ts` composition (order matters)

```ts
// src/proxy.ts (sketch)
import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server'
import createIntlMiddleware from 'next-intl/middleware'
import { routing } from '@/lib/i18n/routing'
const intl = createIntlMiddleware(routing)
const isAdmin = createRouteMatcher(['/admin(.*)', '/api/admin(.*)'])
const GONE = [/^\/tieu-de\/?$/, /^\/portfolio\//, /^\/wp-(admin|login\.php|json)/, /^\/xmlrpc\.php/]

export default clerkMiddleware(async (auth, req) => {
  const { pathname, searchParams } = req.nextUrl
  if (GONE.some((r) => r.test(pathname))) return new NextResponse(null, { status: 410 })
  const legacyId = searchParams.get('page_id') ?? searchParams.get('p')
  if (pathname === '/' && legacyId) return legacyIdRedirect(legacyId, req)   // 301 map of old WP IDs
  if (isAdmin(req)) { await auth.protect(); return NextResponse.next() }
  if (pathname.startsWith('/go/') || pathname.startsWith('/api/')) return NextResponse.next()
  const res = intl(req)
  captureAttribution(req, res)                                              // sets 43l_attr if utm/click ids present
  return res
})
export const config = { matcher: ['/((?!_next|.*\\..*).*)', '/(api|trpc)(.*)'] }
```

## Auth & roles (Clerk)

- Only staff sign in. Roles stored in Clerk `publicMetadata.role ∈ { 'admin', 'editor', 'sales' }` and mirrored to `profiles` via a Clerk webhook (`/api/webhooks/clerk`, verified with svix).
- Session token customisation: include `role` claim (`{"role": "{{user.public_metadata.role}}"}`) so `auth().sessionClaims.role` is available without a DB call.
- `requireRole(roles)` helper used at the top of every admin Server Action and admin page; throws/redirects on failure.
- Permissions: `admin` everything; `editor` content, translations, media, FAQs, routes/rates; `sales` leads and contact events (read, update status, notes).
- The public site never calls Clerk components except `ClerkProvider` scoped to `/admin` (keep Clerk JS off public pages for performance).

## Database access (Drizzle + Supabase)

- Driver: `postgres` (postgres.js) with the Supabase **transaction pooler** connection string; `prepare: false` (required for transaction pooling).
- Single client module `src/db/client.ts` (`server-only` import guard). Migrations via `drizzle-kit` using the **direct/session** connection string.
- The app connects with a server role, so **authorization lives in server code**. RLS is still enabled on every table with no `anon`/`authenticated` policies (deny-all) so the Supabase Data API cannot leak data. If client-side supabase-js is ever needed, use Clerk ↔ Supabase native third-party auth (Supabase dashboard → Auth → Third-party → Clerk) and add policies on `auth.jwt()->>'sub'` — the old Clerk "Supabase JWT template" is deprecated.
- Storage: uploads via server action using the service-role key (`SUPABASE_SERVICE_ROLE_KEY`, server only); reads through public bucket URLs / `next/image`.

## Server Actions pattern

```ts
'use server'
export async function submitLeadAction(_prev: LeadState, formData: FormData): Promise<LeadState> {
  const parsed = leadSchema.safeParse(Object.fromEntries(formData))          // shared Zod schema
  if (!parsed.success) return { status: 'error', fieldErrors: parsed.error.flatten().fieldErrors }
  await verifyTurnstile(formData.get('cf-turnstile-response'))
  await rateLimit(`lead:${await clientKey()}`)                                 // e.g. Upstash or DB-based
  const attribution = await readAttributionCookie()
  const lead = await createLead({ ...parsed.data, ...attribution })
  after(() => sendConversions({ type: 'lead', lead }))                         // next/server `after`
  after(() => notifySales(lead))                                               // Zalo OA / email / Telegram — NEEDS CONFIRMATION
  return { status: 'success', leadId: lead.id }
}
```

Client side: `useActionState(submitLeadAction, initial)` + `useFormStatus`; optimistic UI not needed. Admin mutations follow the same shape plus `requireRole` and `updateTag`.

## State management rules

| Need | Use |
| --- | --- |
| Data for rendering public pages | Server Components + cached queries (no client fetching) |
| Form submission | Server Action + `useActionState` |
| Ephemeral UI state (menu open, calculator inputs, consent choice, dismissed banners) | **Zustand** stores in `src/stores/*` (small, typed, `persist` only for consent/banner) |
| Client-side async data in admin (lead list with filters/pagination, media library, search) | **TanStack Query** calling route handlers in `/api/admin/*` or server functions; invalidate on mutation success |
| URL state (filters on blog/goods page) | `searchParams` (nuqs optional) |

Never mirror server data into Zustand. `QueryClientProvider` mounts only in `/admin` layout (and the calculator if it ever needs live rates).

## Environment variables

| Name | Scope | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | server | Supabase transaction pooler (app runtime) |
| `DATABASE_URL_DIRECT` | server/CI | Direct connection for drizzle-kit migrations |
| `NEXT_PUBLIC_SUPABASE_URL` | public | Storage public URLs |
| `SUPABASE_SERVICE_ROLE_KEY` | server | Storage uploads, admin ops |
| `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY`, `CLERK_WEBHOOK_SIGNING_SECRET` | public/server | Staff auth |
| `NEXT_PUBLIC_SITE_URL` | public | `https://43logistics.vn` |
| `NEXT_PUBLIC_GTM_ID` | public | `GTM-WF967MKT` or new |
| `META_PIXEL_ID`, `META_CAPI_TOKEN` | server | Meta CAPI |
| `TIKTOK_PIXEL_ID`, `TIKTOK_EVENTS_TOKEN` | server | TikTok Events API |
| `GOOGLE_ADS_*` | server | Enhanced/offline conversions (later) |
| `TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY` | public/server | Bot protection |
| `IP_HASH_SALT` | server | Hash IPs for leads/events |

Validate with a Zod `env.ts` at boot; never commit `.env*`.

## Quality harness

- **Lint/format:** ESLint flat config (`eslint-config-next`), Prettier (or Biome) — `next lint` is gone in Next 16.
- **Types:** `tsc --noEmit` strict.
- **Unit (Vitest):** price calculation (chargeable weight, bands, rounding), slug/URL builders, metadata builder, JSON-LD builders, redirect loader, Zod schemas.
- **E2E (Playwright):** home → route → calculator → Zalo click (assert `/go/zalo` 302 + event row), lead form happy/error paths, language switch keeps the equivalent page, admin edit rate → public page shows new price.
- **SEO checks in CI:** every public page has 1 `h1`, canonical, hreflang pairs reciprocal, JSON-LD parses; `check:redirects` against preview deploy.
- **Performance:** Lighthouse CI on `/`, one route page, `/lp/sample/` with budgets from `AGENTS.md`.
- **Next.js DevTools MCP** can be enabled for agent debugging (Next 16 feature).
