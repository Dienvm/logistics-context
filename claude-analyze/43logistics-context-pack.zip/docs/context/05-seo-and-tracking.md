# 05 — SEO & tracking

## Targets

- Organic: route keywords in Vietnamese ("gửi hàng đi {nước}", "gửi hàng {nước} về việt nam", "giá gửi hàng đi {nước}", "hàng cấm gửi đi {nước}") and English ("ship from Vietnam to {country}", "Singapore to Vietnam shipping").
- Paid: Google Ads, Meta, TikTok (and possibly Zalo Ads) landing on route pages or `/lp/*`.
- Technical: Lighthouse SEO 100, valid structured data, zero redirect chains, zero 404s from old URLs.

## Metadata (Next.js Metadata API)

Every page exports `generateMetadata` that reads `page_translations` (`seo_title`, `seo_description`, `og_image_id`, `noindex`).

```ts
// src/lib/seo/build-metadata.ts (shape)
export function buildMetadata({ locale, path, alternates, title, description, ogImage, noindex }: Args): Metadata {
  return {
    metadataBase: new URL('https://43logistics.vn'),
    title,                                   // root layout template: '%s | 43 Logistics'
    description,
    alternates: {
      canonical: path,                       // absolute via metadataBase, trailing slash
      languages: { vi: alternates.vi, en: alternates.en, 'x-default': alternates.vi }, // only locales that are published
    },
    openGraph: { type: 'website', siteName: '43 Logistics', locale: locale === 'vi' ? 'vi_VN' : 'en_US', url: path, title, description, images: ogImage ? [ogImage] : undefined },
    twitter: { card: 'summary_large_image' },
    robots: noindex ? { index: false, follow: true } : { index: true, follow: true, 'max-image-preview': 'large' },
  }
}
```

Length rules enforced in the admin: title ≤ 60 chars, description 120–155 chars, no `&nbsp;`, no year in titles unless it is kept current automatically.

Title/description patterns (defaults when the editor leaves fields empty — always fill real values for P0 pages):

| Page | VI title | EN title |
| --- | --- | --- |
| Outbound route | `Gửi hàng đi {Nước} từ {min}đ/kg – {days} ngày` | `Ship from Vietnam to {Country} – from {min} VND/kg` |
| Inbound route | `Gửi hàng {Nước} về Việt Nam – nhận tại HN, HCM` | `{Country} to Vietnam Shipping – door to door` |
| Hub outbound | `Gửi hàng đi nước ngoài – bảng giá các tuyến` | `International Shipping from Vietnam – Rates by Country` |
| Calculator | `Tính cước gửi hàng đi nước ngoài` | `Shipping Cost Calculator` |
| Blog post | `{Post title}` | `{Post title}` |

Open Graph images: `app/[locale]/(site)/[...]/opengraph-image.tsx` with `next/og` `ImageResponse` — flag + "Gửi hàng đi {Nước}" + "từ {min}đ/kg" + logo, 1200×630, brand colours. Note in Next 16 the `params` passed to metadata image routes is a Promise.

## Hreflang & canonical

- Self-referencing canonical on every indexable page, absolute, with trailing slash, no query string (UTM parameters must never become canonical).
- `hreflang` pairs only when both translations are `published`. `x-default` → Vietnamese URL.
- No automatic locale redirects (no `Accept-Language` / IP redirect); offer a dismissible "View in English?" banner instead.
- `/lp/*`, `/tra-cuu/*`, `/go/*`, `/admin/*`, `/api/*` are `noindex` or disallowed.

## `app/sitemap.ts` & `app/robots.ts`

- Sitemap generated from DB: published, indexable pages + posts, both locales, each entry with `alternates.languages`, `lastModified = updated_at`. Excludes `/lp/*`, tags/authors/dates (not recreated).
- Single `/sitemap.xml`; old `/sitemap_index.xml`, `/post-sitemap.xml`, `/page-sitemap.xml`, `/category-sitemap.xml`, `/post_tag-sitemap.xml`, `/sitemap.rss` 301 → `/sitemap.xml` (see redirect map).
- robots: allow `/`; disallow `/admin/`, `/api/`, `/go/`; `Sitemap: https://43logistics.vn/sitemap.xml`.
- RSS: `/kinh-nghiem/rss.xml`, `/en/guides/rss.xml` (route handlers).

## Structured data (JSON-LD) per page type

Emit with a `<JsonLd data={...} />` server component (`<script type="application/ld+json">`, escaped). Values come from `site_settings`, `routes`, `route_rates`, `faqs`, `posts` — never hard-coded.

| Page type | Schema |
| --- | --- |
| All pages | `WebSite` (name "43 Logistics", alternateName "43Logistics.vn", url, inLanguage) + `Organization` (logo SVG/PNG URL, `sameAs` Facebook, `contactPoint` { telephone "+84979222357", contactType "customer support", availableLanguage ["vi","en"] }) |
| Home, Contact, About | `LocalBusiness` per office (Đà Nẵng, TP.HCM): name, address (`PostalAddress` with confirmed new admin names), `geo`, telephone, `openingHoursSpecification` from settings, `url`, `image` |
| Route pages | `Service` { serviceType "International parcel shipping", provider → Organization, areaServed → `Country` {name}, `offers`: `Offer` with `priceSpecification` `UnitPriceSpecification` { price, priceCurrency "VND", unitCode "KGM", referenceQuantity, eligibleQuantity (min/max kg) }, `validFrom`/`validThrough` from rates } + `BreadcrumbList` + `FAQPage` (Google shows FAQ rich results only for some authoritative sites; still valid markup) |
| Hubs | `ItemList` of route services + `BreadcrumbList` |
| Blog post | `BlogPosting` (headline, image, datePublished, dateModified, author `Organization`, inLanguage, mainEntityOfPage) + `BreadcrumbList` |
| Policy pages | `WebPage` + `BreadcrumbList` |

Do not output `AggregateRating`/`Review` unless reviews are real, collected on-site, and policy-compliant.

## Redirects & legacy URLs

- Source of truth: `data/redirect-map.csv` (`old_url,new_url_vi,new_url_en,status_code,notes`).
- Implementation v1: generate `redirects()` in `next.config.ts` from the CSV at build (≈50 rules, all 301, `permanent: true`), plus `rewrites()` for `/wp-content/uploads/:path*` → Supabase Storage public URL (same path, 200).
- 410 rows (`/tieu-de/`, `/portfolio/*`, `/wp-admin/*`, `/wp-login.php`, `/xmlrpc.php`, `/wp-json/*`): handled in `proxy.ts` returning `new NextResponse(null, { status: 410 })`.
- Old query URLs `/?page_id={id}`, `/?p={id}` → map WP IDs (580, 705, 834, 836, 837, 838, 851, 866, 3596, 694, 3570, 3587) to new URLs in `proxy.ts`.
- `http://` and `www.` → `https://43logistics.vn` at the host/CDN level (one hop).
- Runtime additions later: `redirects` table read in `proxy.ts` (cached), managed in admin.
- `pnpm check:redirects` (Playwright/undici) must pass in CI: every CSV row returns the expected status and `Location`, no chains.

## Performance rules (SEO-relevant)

- Route pages and home are fully static shells (Cache Components) with only the calculator and consent as client islands.
- LCP image: `next/image` with `priority`, correct `sizes`, AVIF/WebP, ≤ 150 KB at 1280 px wide.
- Fonts: 2 families, `display: swap`, subsets latin + vietnamese, preload via `next/font`.
- Third-party: GTM loaded with `@next/third-parties/google` `GoogleTagManager` after consent defaults; no Maps iframe (static map image + link); no chat widget scripts.
- Budgets: JS ≤ 120 KB gz on route pages; CLS < 0.1 (reserve space for sticky bar and images).

## Tracking plan

### Identifiers captured (first-party cookie `43l_attr`, 90 days, set in `proxy.ts` on landing)

`utm_source`, `utm_medium`, `utm_campaign`, `utm_term`, `utm_content`, `gclid`, `gbraid`, `wbraid`, `fbclid` (→ build `_fbc`), `ttclid`, `landing_path`, `referrer`, `first_seen_at`. Attached to every `leads` and `contact_events` row.

### Contact click tracker

`/go/[channel]?from={path}&route={key}` (route handler, `channel ∈ zalo | call | whatsapp | messenger`):
1. Insert `contact_events` row (channel, route, path, attribution, hashed IP, user agent).
2. Fire server-side conversion (see below) with a generated `event_id`.
3. `302` to `https://zalo.me/0979222357` / `tel:+84979222357` / `https://wa.me/84979222357?text=…` / `https://m.me/43logistics`.

The client link also pushes the dataLayer event with the same `event_id` (pass via data attribute) for pixel de-duplication.

### dataLayer events

| Event | When | Parameters |
| --- | --- | --- |
| `click_zalo` / `click_call` / `click_whatsapp` / `click_messenger` | Contact button click | `event_id`, `route_key`, `placement` (header, hero, sticky_bar, rate_table, footer…), `locale` |
| `calculate_quote` | Calculator returns a result | `route_key`, `weight_kg`, `chargeable_kg`, `estimate_vnd`, `locale` |
| `generate_lead` | Lead form success | `event_id`, `route_key`, `lead_id`, `locale`, `value` (estimate if any), `currency: 'VND'` |
| `form_start` / `form_error` | First field focus / validation error | `form: 'lead'`, `field` |
| `view_route` | Route page view | `route_key`, `direction` |
| `select_route` | Route chosen in picker/mega menu | `route_key`, `placement` |

### Platforms

| Platform | Client | Server-side |
| --- | --- | --- |
| GTM | Container `GTM-WF967MKT` (reuse; audit contents — currently `UNKNOWN`) or new container | — |
| GA4 | via GTM; key events: `generate_lead`, `click_zalo`, `click_call` | Measurement Protocol optional |
| Google Ads | via GTM; conversions = lead + Zalo/call clicks | Enhanced Conversions for leads (hashed phone/email); offline conversion import using stored `gclid` when a lead becomes `won` |
| Meta | Pixel via GTM | Conversions API from Server Action / `/go` handler, `event_id` dedupe, `_fbc`/`_fbp`, hashed phone |
| TikTok | Pixel via GTM | Events API, `ttclid`, `event_id` dedupe |

### Consent (Decree 13/2023 + Google Consent Mode v2)

- Default: `ad_storage`, `ad_user_data`, `ad_personalization`, `analytics_storage` = `denied` until the user chooses; functional cookies (`43l_attr`, consent) allowed.
- Banner (VI/EN) with Accept all / Reject / Customize; choice stored (cookie + Zustand), `gtag('consent','update',…)`.
- Server-side conversions only when consent for ads is granted (stored on the lead/event row).
- Lead form has an explicit consent checkbox linking `/chinh-sach-bao-mat/`; store `consent_at` and the policy version.

## Ads landing page checklist

- [ ] Message match: H1, price and offer equal the ad text (variant via `/lp/{campaign}/` content or `?v=` mapped server-side — never reflect raw query text).
- [ ] One primary CTA (Zalo) + one secondary (call); no full navigation.
- [ ] Above the fold on 360×640: H1, from-price, days, CTA.
- [ ] LCP < 2.5 s on 4G; no carousel, no map iframe.
- [ ] `noindex, follow`; canonical to itself; UTM captured.
- [ ] Conversion events verified in GTM preview + platform test tools before launch.
