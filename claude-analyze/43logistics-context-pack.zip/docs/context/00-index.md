# 00 — Context pack index

This folder is the project memory for the 43logistics.vn rebuild. It was produced from a full analysis of the old WordPress site (database dump of 2026-10-18 + live pages). Agents load files on demand; humans keep them current.

## Files

| File | Purpose | Load when |
| --- | --- | --- |
| `../../AGENTS.md` | Rules, stack, conventions, definition of done | Always (auto) |
| `01-business.md` | Company facts, contacts, routes, legacy prices, audience, voice | Any copy, settings, route data |
| `02-legacy-audit.md` | Old-site problems → rules; what to keep | Design/content decisions |
| `03-information-architecture.md` | URLs, sitemap, nav, page section specs, route registry | Pages, routing, navigation |
| `04-design-system.md` | Direction, tokens, Tailwind `@theme`, components, motion | Any UI work |
| `05-seo-and-tracking.md` | Metadata, hreflang, JSON-LD, sitemap/robots, redirects, events, consent, LPs | Pages, SEO, analytics |
| `06-architecture.md` | System diagram, folders, caching, `proxy.ts`, auth, Server Actions, state, env, testing | Scaffolding, infra, any server code |
| `07-data-model.md` | Drizzle schema (draft), settings shapes, blocks, RLS, storage, seed | DB, admin, queries |
| `08-i18n.md` | next-intl routing, slugs, switcher, formatting, translation workflow | Anything locale-related |
| `09-migration.md` | WordPress → new mapping, import steps, media, QA, go-live | Import scripts, launch |
| `10-roadmap.md` | Ordered tasks with acceptance criteria | Picking the next task |
| `11-open-questions.md` | Facts the owner must confirm (Q-IDs) | Before writing any business fact |
| `12-glossary.md` | VI ↔ EN terms | Copy, translations, UI strings |
| `legacy-copy/*.md` | Verbatim old page text (unverified raw material) | Rewriting content |
| `../adr/*.md` | Architecture decisions | Before changing stack/architecture |
| `../../data/design-tokens.json` | Tokens (`current`, `proposed`) | `pnpm tokens`, Figma |
| `../../data/redirect-map.csv` | Old → new URLs (63 rows) | Redirects, QA |
| `../../data/media-inventory.csv` | 330 old media files, used/unused | Media migration |
| `../../data/seed/*.json` | Legacy routes/rates/settings (unverified) | `pnpm db:seed` |

## Prompt starters (VS Code — Claude Code / Copilot Chat)

1. **Scaffold:** "Read AGENTS.md and docs/context/06-architecture.md. Implement roadmap task F-01, then F-02 using data/design-tokens.json. Don't add any page content yet."
2. **Database:** "Implement F-04: create src/db from the draft schema in docs/context/07-data-model.md, fix it against the installed drizzle-orm version, generate migrations, and write scripts/seed.ts that loads data/seed/*.json idempotently."
3. **Proxy & redirects:** "Implement F-06 and F-07. Use data/redirect-map.csv as the only source; add unit tests for every 410 and legacy-ID rule; write scripts/check-redirects.ts."
4. **Route page:** "Implement S-03 (price engine with tests) then S-04 (route page template) following docs/context/03 section 'Outbound route page', 04 components and 05 JSON-LD rules. Prices only from route_rates; show 'liên hệ' when routes.is_verified is false."
5. **Lead flow:** "Implement S-02 and S-08. Follow 05 'Tracking plan' and 06 'Server Actions pattern'. Email must be optional; consent required."
6. **Content rewrite:** "Using docs/context/legacy-copy/gui-hang-di-han-quoc.md as raw material and 01-business.md for facts, draft new VI copy for the Korea route page as blocks JSON. Mark every unconfirmed fact with its Q-ID from 11-open-questions.md. Do not invent numbers."
7. **Review:** "Review this PR against AGENTS.md section 7 (definition of done) and the SEO checks in 05. List violations with file:line."

## Keeping the pack healthy

- One fact, one place: business facts live in `01-business.md` (and later in `site_settings`/`routes`); other files reference them.
- When a question in `11-open-questions.md` is answered, update it and the files it affects in the same commit.
- Stack/architecture changes need a new ADR in `docs/adr/`.
